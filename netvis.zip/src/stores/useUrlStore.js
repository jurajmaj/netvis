import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useUrlStore = create(persist(
  (set) => ({
    url: 'https://alg.vnet.at.cnl.sk/bestPath/',
    setUrl: (url) => set({ url }),
  }),
  {
    name: 'url-storage',
  }
));

export default useUrlStore;
