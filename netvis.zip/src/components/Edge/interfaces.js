export const FAOptions = ["Fa0/0", "Fa0/1", "Fa0/2", "Fa0/3", "Fa0/4", "Fa0/5", "Fa0/6", "Fa0/7", "Fa0/8", "Fa0/9"];
export const GIOptions = ["Gi0/0", "Gi0/1", "Gi0/2", "Gi0/3", "Gi0/4", "Gi0/5", "Gi0/6", "Gi0/7", "Gi0/8", "Gi0/9"];
export const SeOptions = ["Se0/0/0", "Se0/0/1", "Se0/0/2", "Se0/0/3", "Se0/0/4", "Se0/0/5"];