import React, { useCallback, useState, useEffect } from "react";
import { Handle, NodeToolbar, Position, useReactFlow } from "reactflow";
import { FormHelperText } from "@mui/material";

import { ReactComponent as RouterIcon } from "../../assets/Router.svg";
import { ReactComponent as ServerIcon } from "../../assets/Server.svg";
import { ReactComponent as PCIcon } from "../../assets/PC.svg";
import styles from "./Node.module.css";
import NodeMenu from "./NodeMenu";
import useThemeStore from "../../stores/useThemeStore";

function getDeviceIcon(deviceType) {
  let DeviceIcon;
  switch (deviceType) {
    case "routerNode":
      DeviceIcon = RouterIcon;
      break;
    case "pcNode":
      DeviceIcon = PCIcon;
      break;
    case "serverNode":
      DeviceIcon = ServerIcon;
      break;
    default:
      DeviceIcon = RouterIcon;
  }
  return DeviceIcon;
}

function Node({ data, isConnectable }) {
  const { deviceType } = data;
  const { getNodes } = useReactFlow();
  const [label, setLabel] = useState(data.label);
  const [address, setAddress] = useState(data.address);
  const [mask, setMask] = useState(data.mask);
  const [labelError, setLabelError] = useState('');
  const theme = useThemeStore(state => state.theme);

  const handleLabelChange = useCallback((event) => {
    setLabel(event.target.value);

    const newLabel = event.target.value;
    const nodes = getNodes();
    const labels = nodes.map(node => node.data.label);

    if (labels.includes(newLabel)) {
      setLabelError('Please pick unique label!');
    } else {
      setLabelError('');
    }
  }, [getNodes]);

  const handleAddressChange = useCallback((event) => {
    setAddress(event.target.value);
  }, []);

  const handleMaskChange = useCallback((event) => {
    setMask(event.target.value);
  }, []);

  useEffect(() => {
    data.label = label;
    data.address = address;
    data.mask = mask;
  }, [label, address, mask, data]);

  const DeviceIcon = getDeviceIcon(deviceType);

  return (
    <>
      <Handle type="source" isConnectable={isConnectable} position={Position.Top}
              className={DeviceIcon === RouterIcon ? styles.routerHandle : DeviceIcon === PCIcon ? styles.pcHandle : styles.serverHandle} />
      <DeviceIcon className={DeviceIcon === PCIcon ? (theme === 'dark' ? styles.pcIconDark : styles.pcIconLight) : styles.deviceIcon} />
      <label style={{color: theme === 'dark' ? 'white' : 'black'}} className={styles.label}>{label}</label>

      <NodeToolbar position="right">
        {labelError && <FormHelperText error style={{ marginLeft: '15px' }}>{labelError}</FormHelperText>}
        <NodeMenu
          label={label}
          address={address}
          mask={mask}
          handleLabelChange={handleLabelChange}
          handleAddressChange={handleAddressChange}
          handleMaskChange={handleMaskChange}
        />
      </NodeToolbar>
    </>
  );
}

export default Node;