import React from "react";
import { TextField } from "@mui/material";
import styles from "./NodeMenu.module.css";

function NodeMenu({ label, address, mask, handleLabelChange, handleAddressChange, handleMaskChange }) {
  return (
    <div className={styles.NodeMenu}>
      <TextField
        id="outlined-size-small"
        label="Label"
        size="small"
        type="text"
        value={label}
        onChange={handleLabelChange}
        className={styles.labelBox}
      />

      <TextField
        id="outlined-size-small"
        label="Address"
        size="small"
        type="text"
        value={address}
        onChange={handleAddressChange}
        className={styles.addressBox}
      />

      <TextField
        id="outlined-size-small"
        label="Subnet Mask"
        size="small"
        type="text"
        value={mask}
        onChange={handleMaskChange}
        className={styles.maskBox}
      />
    </div>
  );
}

export default NodeMenu;
